<?php
$config['error_prefix'] = '<p class="text-danger error">';
$config['error_suffix'] = '</p>';