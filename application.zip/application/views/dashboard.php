
@script
<script type="text/javascript">
    // to active the sidebar
    $('.dashboard_li').active();
</script>
@endscript
