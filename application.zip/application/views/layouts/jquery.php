<!-- Required Jquery -->
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\jquery\js\jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\jquery-ui\js\jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\popper.js\js\popper.min.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\bootstrap\js\bootstrap.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\jquery-slimscroll\js\jquery.slimscroll.js"></script>
<!-- modernizr js -->
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\modernizr\js\modernizr.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\modernizr\js\css-scrollbars.js"></script>

<!-- data-table js -->
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\datatables.net\js\jquery.dataTables.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\datatables.net-buttons\js\dataTables.buttons.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\assets\pages\data-table\js\jszip.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\assets\pages\data-table\js\pdfmake.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\assets\pages\data-table\js\vfs_fonts.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\datatables.net-buttons\js\buttons.print.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\datatables.net-buttons\js\buttons.html5.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\datatables.net-bs4\js\dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\datatables.net-responsive\js\dataTables.responsive.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\datatables.net-responsive-bs4\js\responsive.bootstrap4.min.js"></script>

<!-- i18next.min.js -->
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\i18next\js\i18next.min.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\i18next-xhr-backend\js\i18nextXHRBackend.min.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\i18next-browser-languagedetector\js\i18nextBrowserLanguageDetector.min.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\jquery-i18next\js\jquery-i18next.min.js"></script>

<!--Forms - Wizard js-->
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\jquery.cookie\js\jquery.cookie.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\jquery.steps\js\jquery.steps.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\bower_components\jquery-validation\js\jquery.validate.js"></script>
<!-- Validation js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\assets\pages\form-validation\validate.js"></script>

<script src="<?php echo $this->assetsUrl; ?>files\assets\js\pcoded.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\assets\js\vartical-layout.min.js"></script>
<script src="<?php echo $this->assetsUrl; ?>files\assets\js\jquery.mCustomScrollbar.concat.min.js"></script>

<!-- sweet alert js -->
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\sweetalert\js\sweetalert.min.js"></script>

<!-- Select 2 js -->
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\select2\js\select2.full.min.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\bower_components\datedropper\js\datedropper.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.js"></script>
<!-- Multiselect js -->
<!--<script type="text/javascript" src="--><?php //echo $this->assetsUrl; ?><!--files\bower_components\bootstrap-multiselect\js\bootstrap-multiselect.js"></script>-->
<!--<script type="text/javascript" src="--><?php //echo $this->assetsUrl; ?><!--files\bower_components\multiselect\js\jquery.multi-select.js"></script>-->
<!--<script type="text/javascript" src="--><?php //echo $this->assetsUrl; ?><!--files\assets\js\jquery.quicksearch.js"></script>-->

<!-- Custom js -->
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\assets\js\script.js"></script>
<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\maintenance.js"></script>
<!--<script type="text/javascript" src="<?php echo $this->assetsUrl; ?>files\assets\pages\google-maps\gmaps.js"></script>-->

<!-- Global site tag (gtag.js) - Google Analytics -->
<!--<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>-->
<script>
    // window.dataLayer = window.dataLayer || [];
    // function gtag(){dataLayer.push(arguments);}
    // gtag('js', new Date());
    //
    // gtag('config', 'UA-23581568-13');
</script>